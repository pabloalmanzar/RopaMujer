import React from 'react';
import { Heart, ShoppingCart } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'Vestido Floral de Verano',
    price: 49.99,
    image: 'https://images.unsplash.com/photo-1612336307429-8a898d10e223?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80',
    category: 'Vestidos',
    isNew: true,
    discount: null,
  },
  {
    id: 2,
    name: 'Blusa de Seda Elegante',
    price: 29.99,
    image: 'https://images.unsplash.com/photo-1551163943-3f7aefc47fe9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80',
    category: 'Blusas',
    isNew: false,
    discount: 15,
  },
  {
    id: 3,
    name: 'Jeans de Cintura Alta',
    price: 59.99,
    image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80',
    category: 'Pantalones',
    isNew: true,
    discount: null,
  },
  {
    id: 4,
    name: 'Zapatos de Tacón Clásicos',
    price: 79.99,
    image: 'https://images.unsplash.com/photo-1535043934128-cf0b28d52f95?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80',
    category: 'Zapatos',
    isNew: false,
    discount: 20,
  },
  {
    id: 5,
    name: 'Sandalias de Verano',
    price: 39.99,
    image: 'https://images.unsplash.com/photo-1562273138-f46be4ebdf33?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80',
    category: 'Zapatos',
    isNew: true,
    discount: null,
  },
  {
    id: 6,
    name: 'Falda Midi Plisada',
    price: 45.99,
    image: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=772&q=80',
    category: 'Faldas',
    isNew: false,
    discount: 10,
  },
  {
    id: 7,
    name: 'Botas de Cuero',
    price: 89.99,
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80',
    category: 'Zapatos',
    isNew: true,
    discount: null,
  },
  {
    id: 8,
    name: 'Chaqueta Vaquera',
    price: 69.99,
    image: 'https://images.unsplash.com/photo-1544022613-e87ca75a784a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80',
    category: 'Chaquetas',
    isNew: false,
    discount: 25,
  },
];

const FeaturedProducts = () => {
  return (
    <div className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold tracking-tight text-black sm:text-4xl">Productos Destacados</h2>
          <p className="mt-4 max-w-2xl text-xl text-black mx-auto">
            Descubre nuestras prendas y zapatos más populares
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
          {products.map((product) => (
            <div key={product.id} className="group relative bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="relative w-full h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-t-lg overflow-hidden group-hover:opacity-75">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-center object-cover"
                />
                {product.isNew && (
                  <div className="absolute top-0 left-0 m-2 bg-black text-white px-2 py-1 text-xs font-bold rounded">
                    NUEVO
                  </div>
                )}
                {product.discount && (
                  <div className="absolute top-0 right-0 m-2 bg-black text-white px-2 py-1 text-xs font-bold rounded">
                    -{product.discount}%
                  </div>
                )}
                <div className="absolute top-0 right-0 m-2 flex flex-col space-y-2">
                  <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-100 focus:outline-none">
                    <Heart size={18} className="text-gray-600" />
                  </button>
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between">
                  <div>
                    <h3 className="text-sm text-black">
                      <a href="#">
                        <span aria-hidden="true" className="absolute inset-0" />
                        {product.name}
                      </a>
                    </h3>
                    <p className="mt-1 text-sm text-black">{product.category}</p>
                  </div>
                </div>
                <div className="mt-2 flex justify-between items-center">
                  <div>
                    {product.discount ? (
                      <div className="flex items-center">
                        <p className="text-sm font-medium text-black">
                          ${(product.price * (1 - product.discount / 100)).toFixed(2)}
                        </p>
                        <p className="ml-2 text-sm font-medium text-gray-500 line-through">
                          ${product.price.toFixed(2)}
                        </p>
                      </div>
                    ) : (
                      <p className="text-sm font-medium text-black">${product.price.toFixed(2)}</p>
                    )}
                  </div>
                  <button className="p-2 bg-black rounded-full shadow-md hover:bg-gray-800 focus:outline-none">
                    <ShoppingCart size={18} className="text-white" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <a
            href="#"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-black hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
          >
            Ver todos los productos
          </a>
        </div>
      </div>
    </div>
  );
};

export default FeaturedProducts;