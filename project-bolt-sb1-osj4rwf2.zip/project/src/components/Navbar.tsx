import React, { useState } from 'react';
import { ShoppingBag, Heart, Search, Menu, X, User, ShoppingCart } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <button
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <div className="flex-shrink-0 flex items-center">
              <ShoppingBag className="h-8 w-8 text-black" />
              <span className="ml-2 text-xl font-bold text-black">IL PRATO</span>
            </div>
            <div className="hidden md:ml-6 md:flex md:space-x-8">
              <a href="#" className="border-black text-black inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                Inicio
              </a>
              <a href="#" className="border-transparent text-black hover:border-gray-300 hover:text-black inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                Ropa
              </a>
              <a href="#" className="border-transparent text-black hover:border-gray-300 hover:text-black inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                Zapatos
              </a>
              <a href="#" className="border-transparent text-black hover:border-gray-300 hover:text-black inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                Accesorios
              </a>
              <a href="#" className="border-transparent text-black hover:border-gray-300 hover:text-black inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                Ofertas
              </a>
            </div>
          </div>
          <div className="flex items-center">
            <div className="hidden md:flex md:items-center md:space-x-4">
              <button className="p-1 rounded-full text-black hover:text-gray-700 focus:outline-none">
                <Search size={20} />
              </button>
              <button className="p-1 rounded-full text-black hover:text-gray-700 focus:outline-none">
                <User size={20} />
              </button>
              <button className="p-1 rounded-full text-black hover:text-gray-700 focus:outline-none">
                <Heart size={20} />
              </button>
              <button className="p-1 rounded-full text-black hover:text-gray-700 focus:outline-none relative">
                <ShoppingCart size={20} />
                <span className="absolute -top-1 -right-1 bg-black text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  3
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`${isMenuOpen ? 'block' : 'hidden'} md:hidden`}>
        <div className="pt-2 pb-3 space-y-1">
          <a href="#" className="bg-gray-50 border-black text-black block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
            Inicio
          </a>
          <a href="#" className="border-transparent text-black hover:bg-gray-50 hover:border-gray-300 hover:text-black block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
            Ropa
          </a>
          <a href="#" className="border-transparent text-black hover:bg-gray-50 hover:border-gray-300 hover:text-black block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
            Zapatos
          </a>
          <a href="#" className="border-transparent text-black hover:bg-gray-50 hover:border-gray-300 hover:text-black block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
            Accesorios
          </a>
          <a href="#" className="border-transparent text-black hover:bg-gray-50 hover:border-gray-300 hover:text-black block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
            Ofertas
          </a>
        </div>
        <div className="pt-4 pb-3 border-t border-gray-200">
          <div className="flex items-center px-4 space-x-3">
            <button className="p-1 rounded-full text-black hover:text-gray-700 focus:outline-none">
              <Search size={20} />
            </button>
            <button className="p-1 rounded-full text-black hover:text-gray-700 focus:outline-none">
              <User size={20} />
            </button>
            <button className="p-1 rounded-full text-black hover:text-gray-700 focus:outline-none">
              <Heart size={20} />
            </button>
            <button className="p-1 rounded-full text-black hover:text-gray-700 focus:outline-none relative">
              <ShoppingCart size={20} />
              <span className="absolute -top-1 -right-1 bg-black text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                3
              </span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;